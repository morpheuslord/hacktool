package console

const (
	SymbolSelection     rune = '▲'
	SymbolVerticalBar   rune = '▎'
	SymbolHorizontalBar rune = '═'
)
